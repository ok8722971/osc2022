#ifndef TYPE_H
#define TYPE_H

typedef int int32_t;
typedef long long int int64_t;

typedef unsigned int uint32_t;
typedef unsigned long long int uint64_t;

#endif
