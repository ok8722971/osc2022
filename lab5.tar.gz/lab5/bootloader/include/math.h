#ifndef MATH_H
#define MATH_H

int pow(int base, int exponent);

#endif
