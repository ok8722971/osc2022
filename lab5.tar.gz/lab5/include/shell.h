#ifndef SHELL_H
#define SHELL_H

void init_shell();
void shell_input(char *cmd);
void normal_input(char *cmd);
void shell_controller(char *cmd);

#endif
