#ifndef ALLOC_H
#define ALLOC_H

void *simple_malloc(unsigned int size);

#endif
