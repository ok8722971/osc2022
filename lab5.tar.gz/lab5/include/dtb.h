#ifndef DTB_H
#define DTB_H

void init_dtb();
void print_dtb_address();
char* dtb_get_struct_address();
char* dtb_get_initrd_address();

#endif
